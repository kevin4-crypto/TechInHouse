/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import entidad.Alumno;
import entidad.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ModelAlumno;
import model.ModelCliente;

/**
 *
 * @author LAB-USR-AQ265-A0303
 */
@WebServlet(name = "cliente", urlPatterns = {"/cliente"})
public class cliente extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet alumno</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet alumno at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String metodo = request.getParameter("metodo");

        if (metodo.equals("registra")) {
            try {
                registra(request, response);
            } catch (ParseException ex) {
                Logger.getLogger(cliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (metodo.equals("lista")) {
            lista(request, response);
        } else if (metodo.equals("actualiza")) {
            actualiza(request, response);
        } else if (metodo.equals("busca")) {
            busca(request, response);
        } else if (metodo.equals("elimina")) {
            elimina(request, response);
        }

    }

    protected void registra(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //se obtiene los parametros
        String nombre = request.getParameter("txtnombre");
        String apellido = request.getParameter("txtapellidos");
        String celular = request.getParameter("txtcelular");
        String telefono = request.getParameter("txttelefono");
        String fechanac = request.getParameter("fechanac");
        String email = request.getParameter("txtcorreo");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
        java.util.Date date = sdf.parse(fechanac);

        java.sql.Date sqlDate = (java.sql.Date) new Date(date.getTime());
        //se crea el objeto alumnos
        Cliente a = new Cliente();
        a.setNombre(nombre);
        a.setApellidos(apellido);
        a.setCelular(celular);
        a.setTelefono(telefono);
        a.setEmail(email);

        //se inseta a la BD el Alumno
        ModelCliente model = new ModelCliente();
        model.insertaCliente(a);

        request.setAttribute("data", "<h1>Servlet alumno at </h1>");
        request.getRequestDispatcher("/Login.jsp").forward(request, response);
    }

    protected void lista(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ModelAlumno model = new ModelAlumno();
        List<Alumno> data = model.listaAlumno();

        //Se almacena en memoria llamada request
        request.setAttribute("data", data);

        //se reenvia el request(con los datos) al jsp listaAlumno.jsp
        request.getRequestDispatcher("/listaAlumno.jsp").forward(request, response);

    }

    protected void actualiza(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        int edad = Integer.parseInt(request.getParameter("edad"));
        int id = Integer.parseInt(request.getParameter("id"));

        //se crea el objeto alumnos
        Alumno a = new Alumno();
        a.setIdtbalumno(id);
        a.setNombre(nombre);
        a.setApellido(apellido);
        a.setEdad(edad);

        //se inserta a la BD el Alumno
        ModelAlumno model = new ModelAlumno();
        model.actualizaAlumno(a);

        //se lista todos los alumnos
        lista(request, response);
    }

    protected void busca(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String id = request.getParameter("id");

        //se inserta a la bd el Alumno
        ModelAlumno model = new ModelAlumno();
        Alumno a = model.buscaAlumno(Integer.parseInt(id));

        //se almacena en memoria llamada request.
        request.setAttribute("data", a);

        //se reenvia el request(con los datos) al jsp listaAlumno.jsp
        request.getRequestDispatcher("/actualizaAlumno.jsp").forward(request, response);
    }

    protected void elimina(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String id = request.getParameter("id");

        //se inserta a la bd el Alumno
        ModelAlumno model = new ModelAlumno();
        model.eliminaAlumno(Integer.parseInt(id));

        //se lista todos los alumnos
        lista(request, response);
    }
}
