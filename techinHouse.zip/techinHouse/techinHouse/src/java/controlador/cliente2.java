/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import entidad.Alumno;
import entidad.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ModelAlumno;
import model.ModelCliente;

/**
 *
 * @author JIMMY
 */
@WebServlet(name = "cliente2", urlPatterns = {"/cliente2"})
public class cliente2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet cliente2</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet cliente2 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String metodo = request.getParameter("metodo");

        if (metodo.equals("registra")) {

            try {
                registra(request, response);
            } catch (ParseException ex) {
                Logger.getLogger(cliente2.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (metodo.equals("lista")) {
            lista(request, response);
        } else if (metodo.equals("actualiza")) {
            actualiza(request, response);
        } else if (metodo.equals("busca")) {
            busca(request, response);
        } else if (metodo.equals("elimina")) {
            elimina(request, response);
        }

    }

    protected void registra(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ParseException {
        //se obtiene los parametros
        String nombre = request.getParameter("txtnombre");
        String apellido = request.getParameter("txtapellidos");
        String celular = request.getParameter("txtcelular");
        String telefono = request.getParameter("txttelefono");

        String email = request.getParameter("txtcorreo");

        //se crea el objeto alumnos
        Cliente a = new Cliente();
        a.setNombre(nombre);
        a.setApellidos(apellido);
        a.setCelular(celular);
        a.setTelefono(telefono);

        a.setEmail(email);

        //se inseta a la BD el Alumno
        ModelCliente model = new ModelCliente();
        model.insertaCliente(a);

        request.setAttribute("data", "<div class=\"alert alert-primary\" role=\"alert\">\n"
                + "  SE REGISTRO CON EXITO\n"
                + "</div>");
        request.getRequestDispatcher("/Login.jsp").forward(request, response);
    }

    protected void lista(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ModelCliente model = new ModelCliente();
        List<Cliente> data = model.ListaCliente();

        //Se almacena en memoria llamada request
        request.setAttribute("data", data);

        //se reenvia el request(con los datos) al jsp listaAlumno.jsp
        request.getRequestDispatcher("/clientes.jsp").forward(request, response);

    }

    protected void actualiza(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String nombre = request.getParameter("txtnombre");
        String apellido = request.getParameter("txtapellidos");
        String celular = request.getParameter("txtcelular");
        String telefono = request.getParameter("txttelefono");

        String email = request.getParameter("txtcorreo");
        int id = Integer.parseInt(request.getParameter("id"));
        //se crea el objeto alumnos
        Cliente a = new Cliente();
        a.setClienteCodigo(id);
        a.setNombre(nombre);
        a.setApellidos(apellido);
        a.setCelular(celular);
        a.setTelefono(telefono);

        a.setEmail(email);

        //se inserta a la BD el Alumno
        ModelCliente model = new ModelCliente();
        model.actualizaCliente(a);

        //se lista todos los alumnos
        lista(request, response);
    }

    protected void busca(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String id = request.getParameter("id");

        //se inserta a la bd el Alumno
        ModelCliente model = new ModelCliente();
        Cliente a = model.buscaCliente(Integer.parseInt(id));

        //se almacena en memoria llamada request.
        request.setAttribute("data", a);

        //se reenvia el request(con los datos) al jsp listaAlumno.jsp
        request.getRequestDispatcher("/actualizacliente.jsp").forward(request, response);
    }

    protected void elimina(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //se obtiene los parametros
        String id = request.getParameter("id");

        //se inserta a la bd el Alumno
        ModelCliente model = new ModelCliente();
        model.eliminaCliente(Integer.parseInt(id));

        //se lista todos los alumnos
        lista(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
