/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entidad.Alumno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

/**
 *
 * @author LAB-USR-AQ265-A0303
 */
public class ModelAlumno {
    
    public int insertaAlumno(Alumno obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into tbalumno values(null,?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, obj.getNombre());
            pstm.setString(2, obj.getApellido());
            pstm.setInt(3, obj.getEdad());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }
    public List<Alumno> listaAlumno()
    {
    List<Alumno> data = new ArrayList<>();
    
        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;
            conn = mysqlDbConnection.getConexion();
            String sql = "select * from tbalumno";
            pstm = conn.prepareStatement(sql);
            rs =  pstm.executeQuery();
            Alumno obj;
            
            while(rs.next())
            {
                obj = new Alumno();
                obj.setIdtbalumno(rs.getInt("idtbalumno"));
                obj.setNombre(rs.getString("nombre"));
                obj.setApellido(rs.getString("apellido"));
                obj.setEdad(rs.getInt("edad"));
                data.add(obj);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
        }
            return data;  
    }
    
    public int actualizaAlumno(Alumno obj)
    {
        int salida = -1;
            try {
                Connection conn;
                PreparedStatement pstm;
                conn = mysqlDbConnection.getConexion();
                String sql = "update tbalumno set nombre=?, apellido=?, edad=? where idtbalumno=?";
                pstm = conn.prepareStatement(sql);
                pstm.setString(1, obj.getNombre());
                pstm.setString(2, obj.getApellido());
                pstm.setInt(3, obj.getEdad());
                pstm.setInt(4, obj.getIdtbalumno());
                salida = pstm.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
            }
                return salida;       
        }
     
    public Alumno buscaAlumno(int idAdlumno)
    {
        Alumno obj = null;
       
        try {
        Connection conn;
        PreparedStatement pstm;
        ResultSet rs;
        
        conn =  mysqlDbConnection.getConexion();
        String sql = "select * from tbalumno where idtbalumno=?";
        pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAdlumno);
        
        rs = pstm.executeQuery();
        if(rs.next())
        {
            obj = new Alumno();
            obj.setIdtbalumno(rs.getInt("idtbalumno"));
            obj.setNombre(rs.getString("nombre"));
            obj.setApellido(rs.getString("apellido"));
            obj.setEdad(rs.getInt("edad"));
        }
        } catch (SQLException ex) {
        Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
    }
        return obj;
    }
    
    public int eliminaAlumno(int idAlumno)
    {
        int salida = -1;
    try {
        Connection conn;
        PreparedStatement pstm;
        conn = mysqlDbConnection.getConexion();
        String sql = "delete from tbalumno where idtbalumno =?";
        pstm = conn.prepareStatement(sql);
        pstm.setInt(1, idAlumno);
        salida = pstm.executeUpdate();
    } catch (SQLException ex) {
        Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
    }
        return salida; 
    }
    
    }
    
    

        

