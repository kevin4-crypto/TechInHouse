package model;

import entidad.Solicitud;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelSolicitud {

    public int insertaSolicitud(Solicitud obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into solicitud values(?,null,?,?,?,?,?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getCliente_codigo());
            pstm.setInt(2, obj.getCod_solicitud());
            pstm.setInt(3, obj.getCod_prioridad());
            pstm.setString(4, obj.getDireccion());
            pstm.setString(5, obj.getReferencia());
            pstm.setString(6, obj.getImagen());
            pstm.setInt(7, obj.getCod_tecnico());
            pstm.setInt(8, obj.getCod_zonas());
            pstm.setString(9, obj.getDetalles());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelSolicitud.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaSolicitud(Solicitud obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update solicitud set cliente_codigo=?, cod_solicitud=null, cod_prioridad=?, direccion=?, referencia=?, imagen=?, cod_tecnico=?, cod_zonas=?, detalles=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getCliente_codigo());
            pstm.setInt(2, obj.getCod_solicitud());
            pstm.setInt(3, obj.getCod_prioridad());
            pstm.setString(4, obj.getDireccion());
            pstm.setString(5, obj.getReferencia());
            pstm.setString(6, obj.getImagen());
            pstm.setInt(7, obj.getCod_tecnico());
            pstm.setInt(8, obj.getCod_zonas());
            pstm.setString(9, obj.getDetalles());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelSolicitud.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Solicitud buscaSolicitud(int idCodigo) {
        Solicitud obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from solicitud where cod_solicitud=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Solicitud();
                obj.setCliente_codigo(rs.getInt("cliente_codigo"));
                obj.setCod_solicitud(rs.getInt("cod_solicitud"));
                obj.setCod_prioridad(rs.getInt("cod_prioridad"));
                obj.setDireccion(rs.getString("direccion"));
                obj.setReferencia(rs.getString("referencia"));
                obj.setImagen(rs.getString("imagen"));
            }
        } catch (SQLException ex) {

            Logger.getLogger(ModelSolicitud.class.getName()).log(Level.SEVERE, null, ex);

        }
        return obj;
    }

    public int eliminaSolicitud(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "delete from solicitud cod_solicitud =?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelSolicitud.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }
}
