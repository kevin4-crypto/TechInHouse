
package model;

import entidad.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelUsuario {
    public int insertaUsuario(Usuario obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into usuario values(null,?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_codigo());
            pstm.setString(2, obj.getUsuario());
            pstm.setString(3, obj.getPassword());
            pstm.setInt(4, obj.getUsuario_perfil());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaUsuario(Usuario obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update usuario set usuario_codigo=null, usuario=?, password=?, usuario_perfil=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_codigo());
            pstm.setString(2, obj.getUsuario());
            pstm.setString(3, obj.getPassword());
            pstm.setInt(4, obj.getUsuario_perfil());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Usuario buscaUsuario(int idCodigo) {
        Usuario obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from usuario where usuario_codigo=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Usuario();
                obj.setUsuario_codigo(rs.getInt("usuario_codigo"));
                obj.setUsuario(rs.getString("usuario"));
                obj.setPassword(rs.getString("password"));
                obj.setUsuario_perfil(rs.getInt("usuario_perfil"));
            }
        } catch (SQLException ex) {

            Logger.getLogger(ModelUsuario.class.getName()).log(Level.SEVERE, null, ex);

        }
        return obj;
    }

    public int eliminaUsuario(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "delete from usuario where usuario_codigo =?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }
}
