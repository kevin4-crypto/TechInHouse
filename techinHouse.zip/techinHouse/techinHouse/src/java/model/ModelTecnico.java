package model;

import entidad.Tecnico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelTecnico {

    public int insertaTecnico(Tecnico obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into tecnico values(?,null,?,?,?,?,?,?,?,?,?,?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_codigo());
            pstm.setInt(2, obj.getCod_tecnico());
            pstm.setString(3, obj.getNombres());
            pstm.setString(4, obj.getApellidos());
            pstm.setString(5, obj.getDireccion());
            pstm.setDate(6, obj.getFecha_nac());
            pstm.setString(7, obj.getCelular());
            pstm.setString(8, obj.getTelefono());
            pstm.setInt(9, obj.getCod_servicio());
            pstm.setInt(10, obj.getCod_estado());
            pstm.setInt(11, obj.getCod_calificacion());
            pstm.setString(12, obj.getRuc());
            pstm.setInt(13, obj.getCod_especialidades());
            pstm.setInt(14, obj.getCod_zonas());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaTecnico(Tecnico obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update tecnico set usuario_codigo=?, cod_tecnico=null, nombres=?, apellidos=?, direccion=?, fechanac=?, celular=?"
                    + "     telefono=?, cod_servicio=?, cod_estado=?, cod_calificacion=?, ruc=?, cod_especialidades=?, cod_zonas=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_codigo());
            pstm.setInt(2, obj.getCod_tecnico());
            pstm.setString(3, obj.getNombres());
            pstm.setString(4, obj.getApellidos());
            pstm.setString(5, obj.getDireccion());
            pstm.setDate(6, obj.getFecha_nac());
            pstm.setString(7, obj.getCelular());
            pstm.setString(8, obj.getTelefono());
            pstm.setInt(9, obj.getCod_servicio());
            pstm.setInt(10, obj.getCod_estado());
            pstm.setInt(11, obj.getCod_calificacion());
            pstm.setString(12, obj.getRuc());
            pstm.setInt(13, obj.getCod_especialidades());
            pstm.setInt(14, obj.getCod_zonas());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Tecnico buscaTecnico(int idCodigo) {
        Tecnico obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from tecnico where cod_tecnico=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Tecnico();
                obj.setUsuario_codigo(rs.getInt("usuario_codigo"));
                obj.setCod_tecnico(rs.getInt("cod_tecnico"));
                obj.setNombres(rs.getString("nombres"));
                obj.setApellidos(rs.getString("apellidos"));
                obj.setDireccion(rs.getString("direccion"));
                obj.setFecha_nac(rs.getDate("fechanac"));
                obj.setCelular(rs.getString("celular"));
                obj.setTelefono(rs.getString("telefono"));
                obj.setCod_servicio(rs.getInt("cod_servicio"));
                obj.setCod_estado(rs.getInt("cod_estado"));
                obj.setCod_calificacion(rs.getInt("cod_calificacion"));
                obj.setRuc(rs.getString("ruc"));
                obj.setCod_especialidades(rs.getInt("cod_especialidades"));
                obj.setCod_zonas(rs.getInt("cod_zonas"));
            }
        } catch (SQLException ex) {

            Logger.getLogger(ModelTecnico.class.getName()).log(Level.SEVERE, null, ex);

        }
        return obj;
    }

    public int eliminaTecnico(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "delete from tecnico where cod_tecnico =?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }
}
