package model;

import entidad.Historial_tecnico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelHistorialTecnico {

    public int insertaHistorial(Historial_tecnico obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into historial_tecnico values(?,?,?,?,null)";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getCod_tecnico());
            pstm.setInt(2, obj.getCod_reniec());
            pstm.setInt(5, obj.getCod_policial());
            pstm.setInt(2, obj.getCod_judicial());
            pstm.setInt(2, obj.getCod_historial());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelHistorialTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaHistorial(Historial_tecnico obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update historial_tecnico set cod_tecnico=null, cod_reniec=?, cod_policial=?, cod_judicial=?, cod_historial=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getCod_tecnico());
            pstm.setInt(2, obj.getCod_reniec());
            pstm.setInt(5, obj.getCod_policial());
            pstm.setInt(2, obj.getCod_judicial());
            pstm.setInt(2, obj.getCod_historial());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelHistorialTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Historial_tecnico buscaHistorial(int idCodigo) {
        Historial_tecnico obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from historial_tecnico where cod_historial=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Historial_tecnico();
                obj.setCod_tecnico(rs.getInt("cod_tecnico"));
                obj.setCod_reniec(rs.getInt("cod_reniec"));
                obj.setCod_policial(rs.getInt("cod_policial"));
                obj.setCod_judicial(rs.getInt("cod_judicial"));
                obj.setCod_historial(rs.getInt("cod_historial"));

            }
        } catch (SQLException ex) {

            Logger.getLogger(ModelHistorialTecnico.class.getName()).log(Level.SEVERE, null, ex);

        }
        return obj;
    }

    public int eliminaHistorial(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "delete from historial_tecnico where cod_historial =?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelHistorialTecnico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

}
