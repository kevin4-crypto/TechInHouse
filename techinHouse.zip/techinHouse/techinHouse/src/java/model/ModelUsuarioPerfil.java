
package model;

import entidad.Usuario_perfil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelUsuarioPerfil {
    public int insertaPerfil(Usuario_perfil obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "insert into usuario_perfil values(null,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_perfil());
            pstm.setString(2, obj.getPerfil());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuarioPerfil.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaPerfil(Usuario_perfil obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update usuario_perfil set usuario_perfil=null, perfil=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, obj.getUsuario_perfil());
            pstm.setString(2, obj.getPerfil());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuarioPerfil.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Usuario_perfil buscaPerfil(int idCodigo) {
        Usuario_perfil obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from usuario_perfil where usuario_perfil=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Usuario_perfil();
                obj.setUsuario_perfil(rs.getInt("usuario_perfil"));
                obj.setPerfil(rs.getString("perfil"));
              }
        } catch (SQLException ex) {

            Logger.getLogger(ModelUsuarioPerfil.class.getName()).log(Level.SEVERE, null, ex);

        }
        return obj;
    }

    public int eliminaPerfil(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "delete from usuario_perfil where usuario_perfil =?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelUsuarioPerfil.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }
}
