/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entidad.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

public class ModelCliente {

    public int insertaCliente(Cliente obj) {
        int salida = -1;
        try {

            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "INSERT INTO `cliente`(`cliente_codigo`, `nombre`, `apellidos`, `celular`, `telefono`, `email`) "
                    + " values(null,?,?,?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, obj.getNombre());
            pstm.setString(2, obj.getApellidos());
            //pstm.setInt(3, obj.getUsuarioCodigo());
            pstm.setString(3, obj.getCelular());
            pstm.setString(4, obj.getTelefono());
            pstm.setString(5, obj.getEmail());
            salida = pstm.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(ModelAlumno.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public int actualizaCliente(Cliente obj) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "update cliente set nombre=?, apellidos=?, celular=?, telefono=?, email=? where cliente_codigo=?";
            pstm = conn.prepareStatement(sql);
            pstm.setString(1, obj.getNombre());
            pstm.setString(2, obj.getApellidos());
            pstm.setString(3, obj.getCelular());
            pstm.setString(4, obj.getTelefono());
            pstm.setString(5, obj.getEmail());
            pstm.setInt(6, obj.getClienteCodigo());
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public Cliente buscaCliente(int idCodigo) {
        Cliente obj = null;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from cliente where cliente_codigo=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Cliente();
                obj.setClienteCodigo(rs.getInt("cliente_codigo"));
                obj.setNombre(rs.getString("nombre"));
                obj.setApellidos(rs.getString("apellidos"));
                obj.setUsuarioCodigo(rs.getInt("usuario_codigo"));
                obj.setCelular(rs.getString("celular"));
                obj.setTelefono(rs.getString("telefono"));
                obj.setEmail(rs.getString("email"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ModelCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return obj;
    }

    public int eliminaCliente(int idCodigo) {
        int salida = -1;
        try {
            Connection conn;
            PreparedStatement pstm;
            conn = mysqlDbConnection.getConexion();
            String sql = "DELETE FROM `cliente` WHERE `cliente_codigo`= ?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);
            salida = pstm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ModelCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return salida;
    }

    public List<Cliente> ListaCliente() {
        List<Cliente> data = new ArrayList<>();

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;
            conn = mysqlDbConnection.getConexion();
            String sql = "SELECT * FROM `cliente`";
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();
            Cliente obj;

            while (rs.next()) {
                obj = new Cliente();
                obj.setClienteCodigo(rs.getInt("cliente_codigo"));
                obj.setNombre(rs.getString("nombre"));
                obj.setApellidos(rs.getString("apellidos"));
                obj.setUsuarioCodigo(rs.getInt("usuario_codigo"));
                obj.setCelular(rs.getString("celular"));
                obj.setTelefono(rs.getString("telefono"));
                obj.setEmail(rs.getString("email"));
                data.add(obj);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ModelCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return data;
    }

}
