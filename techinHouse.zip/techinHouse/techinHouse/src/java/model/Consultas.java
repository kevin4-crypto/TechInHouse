/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entidad.Cliente;
import entidad.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Clock;
import java.util.logging.Level;
import java.util.logging.Logger;
import miConexion.mysqlDbConnection;

/**
 *
 * @author Usuario
 */
public class Consultas extends mysqlDbConnection {

    public boolean autenticacion(String usuario, String contraseña) {
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            String consulta = "select * from usuario where usuario = ? and password = ?";
            pst = getConexion().prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, contraseña);
            rs = pst.executeQuery();

            if (rs.absolute(1)) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("Error" + e);
        } finally {
            try {
                if (getConexion() != null) {
                    getConexion().close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
                System.err.println("Error" + e);
            }

        }
        return false;
    }

    /*public boolean registrar(String usuario, String apellido, String nombre, String Contraseña){
        PreparedStatement pst= null;
        
        try {
            String consulta="insert into usuarios (usuario,apellido,nombre,pass) values (?,?,?,?)";
            pst=getConnection().prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, apellido);
            pst.setString(3, nombre);
            pst.setString(4, Contraseña);
            
            if(pst.executeUpdate()==1){
                return true;
            }
        } catch (Exception ex) {
            System.err.println("Error" + ex);
        }finally {
            try {
                 if(getConnection()!=null) getConnection().close();
                 if(pst != null) pst.close();
            } catch (Exception e) {
                System.err.println("Error" + e);
            }
           
        }
        
        return false;
        
     
    } */
    
    public Cliente buscaUsuario(int idCodigo) {
        Cliente obj = null ;

        try {
            Connection conn;
            PreparedStatement pstm;
            ResultSet rs;

            conn = mysqlDbConnection.getConexion();
            String sql = "select * from cliente where usuario_codigo=?";
            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, idCodigo);

            rs = pstm.executeQuery();
            if (rs.next()) {
                obj = new Cliente();
                obj.setClienteCodigo(rs.getInt("cliente_codigo"));
                obj.setNombre(rs.getString("nombre"));
                obj.setApellidos(rs.getString("apellidos"));
                obj.setUsuarioCodigo(rs.getInt("usuario_codigo"));
                obj.setCelular(rs.getString("celular"));
                obj.setTelefono(rs.getString("telefono"));
      
                obj.setEmail(rs.getString("email"));
            }return obj;
        } catch (SQLException ex) {

            Logger.getLogger(ModelCliente.class.getName()).log(Level.SEVERE, null, ex);

        }
         return obj;
    }

}
