
package entidad;

public class Historial_tecnico {
    private int cod_tecnico;
    private int cod_reniec;
    private int cod_policial;
    private int cod_judicial;
    private int cod_historial;

    public Historial_tecnico() {
    }

    public Historial_tecnico(int cod_tecnico, int cod_reniec, int cod_policial, int cod_judicial, int cod_historial) {
        this.cod_tecnico = cod_tecnico;
        this.cod_reniec = cod_reniec;
        this.cod_policial = cod_policial;
        this.cod_judicial = cod_judicial;
        this.cod_historial = cod_historial;
    }

    public int getCod_tecnico() {
        return cod_tecnico;
    }

    public void setCod_tecnico(int cod_tecnico) {
        this.cod_tecnico = cod_tecnico;
    }

    public int getCod_reniec() {
        return cod_reniec;
    }

    public void setCod_reniec(int cod_reniec) {
        this.cod_reniec = cod_reniec;
    }

    public int getCod_policial() {
        return cod_policial;
    }

    public void setCod_policial(int cod_policial) {
        this.cod_policial = cod_policial;
    }

    public int getCod_judicial() {
        return cod_judicial;
    }

    public void setCod_judicial(int cod_judicial) {
        this.cod_judicial = cod_judicial;
    }

    public int getCod_historial() {
        return cod_historial;
    }

    public void setCod_historial(int cod_historial) {
        this.cod_historial = cod_historial;
    }

    
}
