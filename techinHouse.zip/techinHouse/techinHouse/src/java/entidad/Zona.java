/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;


public class Zona {
    private int codZona;
    private String NombreZona;

    public Zona() {
    }

    public Zona(int codZona, String NombreZona) {
        this.codZona = codZona;
        this.NombreZona = NombreZona;
    }

    public int getCodZona() {
        return codZona;
    }

    public void setCodZona(int codZona) {
        this.codZona = codZona;
    }

    public String getNombreZona() {
        return NombreZona;
    }

    public void setNombreZona(String NombreZona) {
        this.NombreZona = NombreZona;
    }
       
}
