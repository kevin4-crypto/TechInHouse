
package entidad;


public class Usuario_perfil {
    private int usuario_perfil;
    private String perfil;

    public Usuario_perfil() {
    }

    public Usuario_perfil(int usuario_perfil, String perfil) {
        this.usuario_perfil = usuario_perfil;
        this.perfil = perfil;
    }

    public int getUsuario_perfil() {
        return usuario_perfil;
    }

    public void setUsuario_perfil(int usuario_perfil) {
        this.usuario_perfil = usuario_perfil;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }
    
}
