
package entidad;

public class Solicitud {
    private int cliente_codigo;
    private int cod_solicitud;
    private int cod_prioridad;
    private String direccion;
    private String referencia;
    private String imagen;
    private int cod_tecnico;
    private int cod_zonas;
    private String detalles;

    public Solicitud() {
    }

    public Solicitud(int cliente_codigo, int cod_solicitud, int cod_prioridad, String direccion, String referencia, String imagen, int cod_tecnico, int cod_zonas, String detalles) {
        this.cliente_codigo = cliente_codigo;
        this.cod_solicitud = cod_solicitud;
        this.cod_prioridad = cod_prioridad;
        this.direccion = direccion;
        this.referencia = referencia;
        this.imagen = imagen;
        this.cod_tecnico = cod_tecnico;
        this.cod_zonas = cod_zonas;
        this.detalles = detalles;
    }

    public int getCliente_codigo() {
        return cliente_codigo;
    }

    public void setCliente_codigo(int cliente_codigo) {
        this.cliente_codigo = cliente_codigo;
    }

    public int getCod_solicitud() {
        return cod_solicitud;
    }

    public void setCod_solicitud(int cod_solicitud) {
        this.cod_solicitud = cod_solicitud;
    }

    public int getCod_prioridad() {
        return cod_prioridad;
    }

    public void setCod_prioridad(int cod_prioridad) {
        this.cod_prioridad = cod_prioridad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getCod_tecnico() {
        return cod_tecnico;
    }

    public void setCod_tecnico(int cod_tecnico) {
        this.cod_tecnico = cod_tecnico;
    }

    public int getCod_zonas() {
        return cod_zonas;
    }

    public void setCod_zonas(int cod_zonas) {
        this.cod_zonas = cod_zonas;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }
    
    
}
