
package entidad;

import java.sql.Date;

public class Tecnico {
    private int usuario_codigo;
    private int cod_tecnico;
    private String nombres;
    private String apellidos;
    private String direccion;
    //Revisar si se agrega fecha
    private Date fecha_nac;
    private String celular;
    private String telefono;
    private int cod_servicio;
    private int cod_estado;
    private int cod_calificacion;
    private String ruc;
    private int cod_especialidades;
    private int cod_zonas;

    public Tecnico() {
    }

    public Tecnico(int usuario_codigo, int cod_tecnico, String nombres, String apellidos, String direccion, Date fecha_nac, String celular, String telefono, int cod_servicio, int cod_estado, int cod_calificacion, String ruc, int cod_especialidades, int cod_zonas) {
        this.usuario_codigo = usuario_codigo;
        this.cod_tecnico = cod_tecnico;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.fecha_nac = fecha_nac;
        this.celular = celular;
        this.telefono = telefono;
        this.cod_servicio = cod_servicio;
        this.cod_estado = cod_estado;
        this.cod_calificacion = cod_calificacion;
        this.ruc = ruc;
        this.cod_especialidades = cod_especialidades;
        this.cod_zonas = cod_zonas;
    }

    public int getUsuario_codigo() {
        return usuario_codigo;
    }

    public void setUsuario_codigo(int usuario_codigo) {
        this.usuario_codigo = usuario_codigo;
    }

    public int getCod_tecnico() {
        return cod_tecnico;
    }

    public void setCod_tecnico(int cod_tecnico) {
        this.cod_tecnico = cod_tecnico;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(Date fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getCod_servicio() {
        return cod_servicio;
    }

    public void setCod_servicio(int cod_servicio) {
        this.cod_servicio = cod_servicio;
    }

    public int getCod_estado() {
        return cod_estado;
    }

    public void setCod_estado(int cod_estado) {
        this.cod_estado = cod_estado;
    }

    public int getCod_calificacion() {
        return cod_calificacion;
    }

    public void setCod_calificacion(int cod_calificacion) {
        this.cod_calificacion = cod_calificacion;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public int getCod_especialidades() {
        return cod_especialidades;
    }

    public void setCod_especialidades(int cod_especialidades) {
        this.cod_especialidades = cod_especialidades;
    }

    public int getCod_zonas() {
        return cod_zonas;
    }

    public void setCod_zonas(int cod_zonas) {
        this.cod_zonas = cod_zonas;
    }
    
    
}
