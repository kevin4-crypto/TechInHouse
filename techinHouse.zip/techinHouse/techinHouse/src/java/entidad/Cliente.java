package entidad;

import java.sql.Date;

public class Cliente {

    private int clienteCodigo;
    private String nombre;
    private String apellidos;
    private int usuarioCodigo;
    private String celular;
    private String telefono;
    private String email;

    public Cliente() {
    }

    public Cliente(int clienteCodigo, String nombre, String apellidos, int usuarioCodigo, String celular, String telefono, String email) {
        this.clienteCodigo = clienteCodigo;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.usuarioCodigo = usuarioCodigo;
        this.celular = celular;
        this.telefono = telefono;
        this.email = email;
    }

    public int getClienteCodigo() {
        return clienteCodigo;
    }

    public void setClienteCodigo(int clienteCodigo) {
        this.clienteCodigo = clienteCodigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getUsuarioCodigo() {
        return usuarioCodigo;
    }

    public void setUsuarioCodigo(int usuarioCodigo) {
        this.usuarioCodigo = usuarioCodigo;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

   public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
}
