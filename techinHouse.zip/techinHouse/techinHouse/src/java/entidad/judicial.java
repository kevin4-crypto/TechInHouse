/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

public class judicial {
    private int codJudicial;
    private String informacion;

    public judicial() {
    }
   
    public judicial(int codJudicial, String informacion) {
        this.codJudicial = codJudicial;
        this.informacion = informacion;
    }

    public int getCodJudicial() {
        return codJudicial;
    }

    public void setCodJudicial(int cod_judicial) {
        this.codJudicial = cod_judicial;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }
    
 }








