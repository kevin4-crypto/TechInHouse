
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;


public class Reniec {
    
    private int codReniec;
    private String informacion;

    public Reniec() {
    }

    public Reniec(int codReniec, String informacion) {
        this.codReniec = codReniec;
        this.informacion = informacion;
    }

    public int getCodReniec() {
        return codReniec;
    }

    public void setCodReniec(int codReniec) {
        this.codReniec = codReniec;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }


}
