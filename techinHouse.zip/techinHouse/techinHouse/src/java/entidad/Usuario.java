
package entidad;


public class Usuario {
    private int usuario_codigo;
    private String usuario;
    private String password;
    private int usuario_perfil;

    public Usuario() {
    }

    public Usuario(int usuario_codigo, String usuario, String password, int usuario_perfil) {
        this.usuario_codigo = usuario_codigo;
        this.usuario = usuario;
        this.password = password;
        this.usuario_perfil = usuario_perfil;
    }

    public int getUsuario_codigo() {
        return usuario_codigo;
    }

    public void setUsuario_codigo(int usuario_codigo) {
        this.usuario_codigo = usuario_codigo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUsuario_perfil() {
        return usuario_perfil;
    }

    public void setUsuario_perfil(int usuario_perfil) {
        this.usuario_perfil = usuario_perfil;
    }
    
    
}
