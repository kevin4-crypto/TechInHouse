/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;


public class Prioridad {
    private int codPrioridad;
    private String prioridad;
    
     public Prioridad() {
    }

    public Prioridad(int codPrioridad, String prioridad) {
        this.codPrioridad = codPrioridad;
        this.prioridad = prioridad;
    }

    public int getCodPrioridad() {
        return codPrioridad;
    }

    public void setCodPrioridad(int codPrioridad) {
        this.codPrioridad = codPrioridad;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }
    
}
