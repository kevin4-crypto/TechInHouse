/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;


public class TipoServicio {
    private int codServicio;
    private String servicio;

    public TipoServicio() {
    }
    
    public TipoServicio(int codServicio, String servicio) {
        this.codServicio = codServicio;
        this.servicio = servicio;
    }

    public int getCodServicio() {
        return codServicio;
    }

    public void setCodServicio(int codServicio) {
        this.codServicio = codServicio;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

}